<?php
header('Content-Type: application/json');

$apiUrl = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=AIzaSyCO48KB8A91GVaD3nWb5ZDVZuPg6HkMR2M"; 
$inputData = json_decode(file_get_contents('php://input'), true);

if (isset($inputData['userInput'])) {
    $userInput = $inputData['userInput'];

    
    $data = [
        'contents' => [
            [
                'parts' => [
                    [
                        'text' => $userInput
                    ]
                ]
            ]
        ]
    ];

    $options = [
        'http' => [
            'header'  => "Content-Type: application/json\r\n",
            'method'  => 'POST',
            'content' => json_encode($data)
        ]
    ];

    $context  = stream_context_create($options);
    $result = file_get_contents($apiUrl, false, $context);

    if ($result === FALSE) {
        
        echo json_encode(['error' => 'Unable to fetch response from AI.']);
        exit;
    }

    echo $result; 
} else {
    echo json_encode(['error' => 'No input provided.']);
}
?>
