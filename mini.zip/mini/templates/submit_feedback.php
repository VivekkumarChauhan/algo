<?php
	include_once 'config.php';
 ?>
 

<?php 
     $name = $_POST["name"];
	 $mail =  $_POST["email"];
	 $message  = $_POST["message"];
	 
	  
	   $sql = "INSERT INTO submit_feedback(id,name,email,message)VALUES ('','$name','$mail','$message')";
	

	  
	  if(mysqli_query($conn,$sql)) {
		  echo "<script> alert('Record inserted successfully!!!')</script>";
		  header("Location:home.html");
	  }
	  else{
		  echo"<script>alert('Error in ')</script>";
	  }
	  
	  mysqli_close($conn);
  ?>
